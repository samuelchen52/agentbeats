Title: Agent Beats
by David Chen, Samuel Chen, and Christopher Liang

Firebase URL: https://agent-beats.firebaseapp.com/benchmark1.html

Source Control URL: https://bitbucket.org/davidc97/agentbeats/src/master/
